/** Shared domain types used across pages and hooks. */

export interface Profile {
  id: string;
  username: string | null;
  first_name: string | null;
  middle_name: string | null;
  last_name: string | null;
  suffix: string | null;
  designation: string | null;
  immediate_head_id: string | null;
  plant_assignments: string[];
  status: 'Pending' | 'Active' | 'Suspended';
  profile_complete: boolean;
  /** Admin-approval flag (replaces Supabase email confirmation, iter 9) */
  confirmed?: boolean;
}
