/**
 * Derive a coarse-grained access level badge from the user's roles.
 * Admin → Full access, Manager → Elevated, Supervisor → Limited,
 * Operator/Technician/other → Restricted.
 */
export function accessLevelFromRoles(roles: string[] | undefined | null): {
  label: string;
  tone: 'accent' | 'warn' | 'muted';
} {
  const r = new Set((roles ?? []).map((x) => x.toLowerCase()));
  if (r.has('admin')) return { label: 'Full access', tone: 'accent' };
  if (r.has('manager')) return { label: 'Elevated', tone: 'accent' };
  if (r.has('supervisor')) return { label: 'Limited', tone: 'warn' };
  return { label: 'Restricted', tone: 'muted' };
}
