/** Canonical designation list shared between DesignationCombobox and Employees. */
export const DEFAULT_DESIGNATIONS = ['Admin', 'Manager', 'Supervisor', 'Operator'] as const;
export type Designation = typeof DEFAULT_DESIGNATIONS[number];
